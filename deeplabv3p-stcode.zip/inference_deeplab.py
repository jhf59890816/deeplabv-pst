import ascendcl as acs
import numpy as np

# 初始化AscendCL环境
acs.init()
context = acs.init_context()
model = acs.load_model(context, "DeepLabv3_Plus.om")

# 准备输入数据
input_data = np.random.rand(1, 3, 512, 512).astype(np.float32)
input_mem = acs.alloc_npu_mem(input_data)
output_mem = acs.alloc_npu_mem(shape=(1000,))  # 假设输出大小为1000

# 执行推理
acs.run(model, input_mem, output_mem)

# 解析输出数据
output_data = acs.copy_npu_mem_to_host(output_mem)
print(output_data)
