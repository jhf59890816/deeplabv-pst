from .model import Linknet

__all__ = ["Linknet"]
