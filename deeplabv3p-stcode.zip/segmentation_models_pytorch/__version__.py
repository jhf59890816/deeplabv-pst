VERSION = (0, 3, "5dev0")

__version__ = ".".join(map(str, VERSION))
