import numpy as np
from mindspore import context, Tensor
from mindspore.train.serialization import load
from PIL import Image

# 设置MindSpore的执行模式和设备
context.set_context(mode=context.GRAPH_MODE, device_target="Ascend")

# 加载.om模型
model_path = "deeplabv3.om"
model = load(model_path)

# 数据预处理函数
def preprocess(image_path):
    # 加载图像
    image = Image.open(image_path)
    # 调整图像大小到模型输入尺寸
    input_size = (1024, 1024) # 假设模型输入是1024x1024
    image = image.resize(input_size)
    # 转换为浮点数并归一化
    image = np.array(image).astype(np.float32)
    image = image / 255.0 # 归一化到[0, 1]
    # 转换为模型输入需要的格式
    image = image.transpose((2, 0, 1)) # HWC到CHW
    image = np.expand_dims(image, axis=0) # 添加batch维度
    return Tensor(image)

# 进行推理
def infer(model, image_path):
    input_data = preprocess(image_path)
    outputs = model(input_data)
    # 假设输出是 segmentation map，需要反归一化等处理
    # 这里只是返回原始输出
    return outputs

# 测试代码
image_path = "1.jpg" # 替换为你的图像路径
output = infer(model, image_path)

# 打印输出，实际使用时你可能需要将其转换为可视化格式
print(output)
