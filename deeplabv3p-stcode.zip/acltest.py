import sys
import os
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"

# home_path = !echo ${HOME}
# sys.path.append(os.path.join(home_path[0] , "jupyter-notebook/"))
print('System init success.')

# atlas_utils是昇腾团队基于pyACL封装好的一套工具库，如果您也想引用的话，请首先将
# https://gitee.com/ascend/samples/tree/master/python/common/atlas_utils
# 这个路径下的代码引入您的工程中
from atlas_utils.acl_resource import AclResource
from constants import *
from acl_model import Model

# 创建一个AclResource类的实例
acl_resource = AclResource()
#AscendCL资源初始化（封装版本）
acl_resource.init()

# 上方“init”方法具体实现（仅供参考），请阅读“init()”方法，观察初始化和运行时资源申请的详细操作步骤
def init(self):
    """
    Init resource
    """
    print("init resource stage:")
    ret = acl.init()
    utils.check_ret("acl.init", ret)

    #指定用于运算的Device
    ret = acl.rt.set_device(self.device_id)
    utils.check_ret("acl.rt.set_device", ret)
    print("Set device n success.")

    #显式创建一个Context
    self.context, ret = acl.rt.create_context(self.device_id)
    utils.check_ret("acl.rt.create_context", ret)

    #创建一个Stream
    self.stream, ret = acl.rt.create_stream()
    utils.check_ret("acl.rt.create_stream", ret)

    #获取当前昇腾AI软件栈的运行模式
    #0：ACL_DEVICE，表示运行在Device的Control CPU上或开发者版上
    #1：ACL_HOST，表示运行在Host CPU上
    self.run_mode, ret = acl.rt.get_run_mode()
    utils.check_ret("acl.rt.get_run_mode", ret)

    print("Init resource success")

# 请阅读下方代码，观察释放运行时资源的详细操作步骤
def __del__(self):
    print("acl resource release all resource")
    resource_list.destroy()

    # 调用acl.rt.destroy_stream接口释放Stream
    if self.stream:
        acl.rt.destroy_stream(self.stream)
        print("acl resource release stream")

    # 调用acl.rt.destroy_context接口释放Context
    if self.context:
        acl.rt.destroy_context(self.context)
        print("acl resource release context")

    # 调用acl.rt.destroy_context接口释放Context
    acl.rt.reset_device(self.device_id)
    acl.finalize()
    print("Release acl resource success")
